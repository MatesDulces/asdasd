package papu;

public class INICIO {

	public void setVisible(boolean b) {
		// TODO Auto-generated method stub
		
	}

}
