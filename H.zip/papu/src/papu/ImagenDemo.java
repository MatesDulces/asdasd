package papu;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.Timer;
import javax.swing.border.EmptyBorder;
import java.awt.SystemColor;

public class ImagenDemo extends JFrame {

    private JPanel contentPane;
    private JButton[] buttons;
    private int selectedIndex = 0;
    private Timer blinkTimer;
    private boolean isBlinking = false;
    private JLabel leftArrow;
    private JLabel rightArrow;
    private JLabel lblNewLabel;
    private JLabel lblNewLabel_1;

    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(() -> {
            try {
                ImagenDemo frame = new ImagenDemo();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }
    
    private static void comenzar() {
        INICIO miINICIO = new INICIO();
        miINICIO.setVisible(true);
    }
    
    private static void salir() {
        System.exit(0); // Salir de la aplicaci�n
    }

    public ImagenDemo() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(350, 50, 700, 700);

        contentPane = new SpaceBackgroundPanel(); // Cambiado aqu�
        contentPane.setBackground(new Color(0, 0, 0));
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null); 

        // Cargar y escalar la imagen del t�tulo
        ImageIcon originalIcon = new ImageIcon(getClass().getResource("GICHI-MICHI-WOO (1).png"));
        Image img = originalIcon.getImage();
        Image scaledImg = img.getScaledInstance(390, 109, Image.SCALE_SMOOTH);

        // Inicializar las flechitas
        leftArrow = new JLabel(">>");
        rightArrow = new JLabel("<<");
        leftArrow.setFont(leftArrow.getFont().deriveFont(20f));
        rightArrow.setFont(rightArrow.getFont().deriveFont(20f));
        leftArrow.setForeground(Color.YELLOW);
        rightArrow.setForeground(Color.YELLOW);
        leftArrow.setBounds(100, 250, 30, 50); // Ajusta la posici�n inicial
        rightArrow.setBounds(470, 250, 30, 50); // Ajusta la posici�n inicial
        leftArrow.setVisible(false); // Ocultar inicialmente
        rightArrow.setVisible(false); // Ocultar inicialmente
        contentPane.add(leftArrow);
        contentPane.add(rightArrow);

        // Crear los botones
        JButton btnQuitGame = createButton("SALIR", 235, 300, e -> salir());
        JButton btnInicio = createButton("INICIO", 235, 500, e -> comenzar());

        lblNewLabel = new JLabel(new ImageIcon("C:\\Users\\Alumno\\Downloads\\GICHI-MICHI-WOO (1).png"));
        lblNewLabel.setBounds(0, 0, 684, 248); // Ajusta el tama�o y la posici�n
        contentPane.add(lblNewLabel);
        
        lblNewLabel_1 = new JLabel("New label");
        lblNewLabel_1.setIcon(new ImageIcon("C:\\Users\\Alumno\\Downloads\\pixil-frame-0 (1).png"));
        lblNewLabel_1.setBounds(-100, -752, 871, 1413);
        contentPane.add(lblNewLabel_1);

        // Agregar botones al arreglo
        buttons = new JButton[]{btnInicio, btnQuitGame};

        // Inicializar el bot�n seleccionado
        updateButtonSelection();

        // Configurar el KeyListener
        addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {}
            @Override
            public void keyPressed(KeyEvent e) {
                handleKeyPress(e);
            }
            @Override
            public void keyReleased(KeyEvent e) {}
        });
        setFocusable(true); // Aseg�rate de que el frame pueda recibir el foco
    }

    private JButton createButton(String text, int x, int y, ActionListener actionListener) {
        JButton button = new JButton(text);
        button.addActionListener(new ActionListener() {
        });
        button.addActionListener(new ActionListener() {
        });
        button.setBounds(x, y, 200, 50);
        button.setBackground(new Color(128, 128, 128));
        button.setForeground(Color.WHITE);
        button.setFont(button.getFont().deriveFont(20f));
        button.setFocusPainted(false); // Elimina el borde de enfoque
        button.setBorderPainted(false); // Elimina el borde del bot�n
        button.addActionListener(actionListener);
        contentPane.add(button);
        return button;
    }

    private void handleKeyPress(KeyEvent e) {
        int key = e.getKeyCode();
        if (key == KeyEvent.VK_UP || key == KeyEvent.VK_W) {
            selectPreviousButtonVertical();  // Navegaci�n vertical
        } else if (key == KeyEvent.VK_DOWN || key == KeyEvent.VK_S) {
            selectNextButtonVertical();  // Navegaci�n vertical
        } else if (key == KeyEvent.VK_LEFT || key == KeyEvent.VK_A) {
            selectPreviousButtonHorizontal();  // Navegaci�n horizontal
        } else if (key == KeyEvent.VK_RIGHT || key == KeyEvent.VK_D) {
            selectNextButtonHorizontal();  // Navegaci�n horizontal
        } else if (key == KeyEvent.VK_ENTER || key == KeyEvent.VK_SPACE) {
            buttons[selectedIndex].doClick();
        }
    }

    private void selectPreviousButtonVertical() {
        if (selectedIndex > 0) {
            selectedIndex = Math.max(selectedIndex - 2, 0);
        }
        updateButtonSelection();
    }

    private void selectNextButtonVertical() {
        if (selectedIndex < buttons.length - 1) {
            selectedIndex = Math.min(selectedIndex + 2, buttons.length - 1);
        }
        updateButtonSelection();
    }

    private void selectPreviousButtonHorizontal() {
        if (selectedIndex > 0) {
            selectedIndex--;
        }
        updateButtonSelection();
    }

    private void selectNextButtonHorizontal() {
        if (selectedIndex < buttons.length - 1) {
            selectedIndex++;
        }
        updateButtonSelection();
    }

    private void updateButtonSelection() {
        if (blinkTimer != null) {
            blinkTimer.stop();
        }
        for (int i = 0; i < buttons.length; i++) {
            JButton button = buttons[i];
            if (i == selectedIndex) {
                // Efecto de titilaci�n en el texto
                blinkTimer = new Timer(400, e -> {
                    if (isBlinking) {
                        button.setForeground(Color.WHITE); // Texto en color blanco
                    } else {
                        button.setForeground(Color.BLACK); // Texto en color negro
                    }
                    isBlinking = !isBlinking;
                });
                blinkTimer.start();

                // Mostrar flechitas y ajustar su posici�n
                leftArrow.setVisible(true);
                rightArrow.setVisible(true);
                int arrowOffset = 10; // Distancia entre el bot�n y las flechitas
                leftArrow.setBounds(button.getX() - leftArrow.getWidth() - arrowOffset, button.getY(), leftArrow.getWidth(), leftArrow.getHeight());
                rightArrow.setBounds(button.getX() + button.getWidth() + arrowOffset, button.getY(), rightArrow.getWidth(), rightArrow.getHeight());
            } else {
                button.setForeground(Color.WHITE); // Texto de otros botones
            }
        } 
    }

    private static class SpaceBackgroundPanel extends JPanel {
        public SpaceBackgroundPanel() {
            setOpaque(true); // Panel opaco para mostrar un color s�lido
            setBackground(Color.BLACK); // Color de fondo negro
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            // Aqu� no es necesario hacer nada, ya que el fondo es s�lido
        }
    }
}
